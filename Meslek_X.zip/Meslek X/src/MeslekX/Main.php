<?php

namespace MeslekX;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\event\Listener;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\Event;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\event\player\PlayerJoinEvent;
use _64FF00\PureChat\PureChat;
use pocketmine\item\Item;
use pocketmine\block\Block;
use pocketmine\{Player, Server};
use pocketmine\utils\Config;
use onebone\economyapi\EconomyAPI;

class Main extends PluginBase implements Listener {
    
    public $config;
    public $oduncu;
    public $mtp;
    public $gmaas;
    public $oseviye;
    public $mseviye;
    public $madenci;
    public $seviye;
    public $sigorta;
    
    
	public function onLoad(){
		$this->getLogger()->info("§eMeslek X Yükleniyor");
	}

	public function onEnable(){


		@mkdir($this->getDataFolder());
        
		$this->madenci = new Config($this->getDataFolder() . "madenci.yml", Config::YAML);
		$this->seviye = new Config($this->getDataFolder() . "seviyeler.yml", Config::YAML);
		$this->sigorta = new Config($this->getDataFolder() . "sigorta.yml", Config::YAML);
		$this->mtp = new Config($this->getDataFolder() . "mtp.yml", Config::YAML);
		$this->gmaas = new Config($this->getDataFolder() . "gmaas.yml", Config::YAML);
		$this->oduncu = new Config($this->getDataFolder() . "oduncu.yml", Config::YAML);
		$this->oseviye = new Config($this->getDataFolder() . "oduncuseviye.yml", Config::YAML);
  	$this->cfg = new Config($this->getDataFolder()."config.yml", Config::YAML);
		$this->mseviye = new Config($this->getDataFolder() . "madenciseviye.yml", Config::YAML);
		
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
		$kaydet = $this->getServer()->getPluginManager();
		
		
		
    	$this->getLogger()->info("§a
    	
    	
    __  ___          __     __  _  __
   /  |/  /__  _____/ /__  / /_| |/ /
  / /|_/ / _ \/ ___/ / _ \/ //_/   / 
 / /  / /  __(__  ) /  __/ ,< /   |  
/_/  /_/\___/____/_/\___/_/|_/_/|_|  
                                     
    	");
    
}



	public function onCommand(CommandSender $cs, Command $cmd, string $label, array $args): bool{
		$player = $cs->getPlayer();
		switch($cmd->getName()){
			case "meslek":
			    
        $meslekc = new Config($this->getDataFolder()."meslekler.yml", Config::YAML);
                    $meslek = $meslekc->get($player->getName());
                    if($meslek == "bos"){
                        $this->mesleksec($player);
                      $meslekc->save();
                    }elseif($meslek == "oduncu"){
                        $this->oduncuxs($player);
                $meslekc->save();
                    }elseif($meslek == "madenci"){
                        $this->madencis($player);
                    $meslekc->save();
                      
                    }
                    return true;
	}
	}
   public function giris(PlayerJoinEvent $e){
      	$ad = $e->getPlayer()->getName();
 $player = $e->getPlayer();
 $oyuncu = $player->getName();
 
if($player->hasPlayedBefore() == false) {

            $this->oduncu->set($ad, 0);
        $this->madenci->set($ad, 0);
        $this->gmaas->set($ad, 250);
        $this->sigorta->set($player->getName(), "yok");
        $this->mseviye->set($ad, 0);
        $this->seviye->set($ad, 0);
        $meslekc = new Config($this->getDataFolder()."meslekler.yml", Config::YAML);
        $meslekc->set($player->getName(), "bos");
        
        $meslekc->save();
        $this->gmaas->save();
        $this->sigorta->save();
        $this->oduncu->save();
        $this->seviye->save();
        $this->mseviye->save();
        $this->madenci->save();

		} else{

     $player->sendPopup("§7");
}
}
	public function ok($k){
		$ad = $k->getPlayer()->getName();
		$oyuncu = $k->getPlayer();
		$random = rand(1,8);
       	switch($random){
			case 1:
               $this->gmaas->set($ad,$this->gmaas->get($ad) +0.5);
			break;
			case 2:
               $this->gmaas->set($ad,$this->gmaas->get($ad) +0.2);
			break;
			case 3:
               $this->gmaas->set($ad,$this->gmaas->get($ad) +0.5);
			break;
			case 4:
               $this->gmaas->set($ad,$this->gmaas->get($ad) +0.4);
			break;
			case 5:
               $this->gmaas->set($ad,$this->gmaas->get($ad) +0.5);
			break;
			case 6:
               $this->gmaas->set($ad,$this->gmaas->get($ad) +0.1);
			break;
			case 7:
               $this->gmaas->set($ad,$this->gmaas->get($ad) +0.3);
			break;
			case 8:
               $this->gmaas->set($ad,$this->gmaas->get($ad) +0.2);
			break;
	    }
	}
	public function okk($k){
		$ad = $k->getPlayer()->getName();
		$oyuncu = $k->getPlayer();
		$random = rand(1,8);
       	switch($random){
			case 1:
               $this->gmaas->set($ad,$this->gmaas->get($ad) +0.9);
        $this->gmaas->save();
			break;
			case 2:
               $this->gmaas->set($ad,$this->gmaas->get($ad) +0.8);
        $this->gmaas->save();
			break;
			case 3:
               $this->gmaas->set($ad,$this->gmaas->get($ad) +0.7);
        $this->gmaas->save();
			break;
			case 4:
               $this->gmaas->set($ad,$this->gmaas->get($ad) +1);
        $this->gmaas->save();
			break;
			case 5:
               $this->gmaas->set($ad,$this->gmaas->get($ad) +0.6);
        $this->gmaas->save();
			break;
			case 6:
               $this->gmaas->set($ad,$this->gmaas->get($ad) +0.4);
        $this->gmaas->save();
			break;
			case 7:
               $this->gmaas->set($ad,$this->gmaas->get($ad) +0.5);
        $this->gmaas->save();
			break;
			case 8:
               $this->gmaas->set($ad,$this->gmaas->get($ad) +0.5);
        $this->gmaas->save();
			break;
	    }
	}
	public function okkk($k){
		$ad = $k->getPlayer()->getName();
		$oyuncu = $k->getPlayer();
		$random = rand(1,8);
       	switch($random){
			case 1:
               $this->gmaas->set($ad,$this->gmaas->get($ad) +1);
        $this->gmaas->save();
			break;
			case 2:
               $this->gmaas->set($ad,$this->gmaas->get($ad) +1);
        $this->gmaas->save();
			break;
			case 3:
               $this->gmaas->set($ad,$this->gmaas->get($ad) +1.2);
        $this->gmaas->save();
			break;
			case 4:
               $this->gmaas->set($ad,$this->gmaas->get($ad) +1);
        $this->gmaas->save();
			break;
			case 5:
               $this->gmaas->set($ad,$this->gmaas->get($ad) +1);
        $this->gmaas->save();
			break;
			case 6:
               $this->gmaas->set($ad,$this->gmaas->get($ad) +1.4);
        $this->gmaas->save();
			break;
			case 7:
               $this->gmaas->set($ad,$this->gmaas->get($ad) +5);
        $this->gmaas->save();
			break;
			case 8:
               $this->gmaas->set($ad,$this->gmaas->get($ad) +2);
        $this->gmaas->save();
			break;
	    }
	}
	public function okkkk($k){
		$ad = $k->getPlayer()->getName();
		$oyuncu = $k->getPlayer();
		$random = rand(1,8);
       	switch($random){
			case 1:
               $this->gmaas->set($ad,$this->gmaas->get($ad) +0.9);
        $this->gmaas->save();
			break;
			case 2:
               $this->gmaas->set($ad,$this->gmaas->get($ad) +0.3);
        $this->gmaas->save();
			break;
			case 3:
               $this->gmaas->set($ad,$this->gmaas->get($ad) +0.8);
        $this->gmaas->save();
			break;
			case 4:
               $this->gmaas->set($ad,$this->gmaas->get($ad) +0.9);
        $this->gmaas->save();
			break;
			case 5:
               $this->gmaas->set($ad,$this->gmaas->get($ad) +0.2);
        $this->gmaas->save();
			break;
			case 6:
               $this->gmaas->set($ad,$this->gmaas->get($ad) +0.1);
        $this->gmaas->save();
			break;
			case 7:
               $this->gmaas->set($ad,$this->gmaas->get($ad) +0.4);
        $this->gmaas->save();
			break;
			case 8:
               $this->gmaas->set($ad,$this->gmaas->get($ad) +0.6);
        $this->gmaas->save();
			break;
	    }
	}
	public function madencik(BlockBreakEvent $e){
		$ad = $e->getPlayer()->getName();
		$player = $e->getPlayer();	
	$block = $e->getBlock();
	
	if($e->getBlock()->getId() == 1){
	    
               $this->madenci->set($ad,$this->madenci->get($ad) +1);
        $this->oduncu->save();
        $this->gmaas->save();
        $this->madenci->save();
		if($this->seviye->get($ad) == 0){
        $this->ok($player);
        $this->oduncu->save();
        $this->gmaas->save();
        $this->madenci->save();
                    }elseif($this->seviye->get($ad) == 1){
                        
        $this->okk($player);
        $this->oduncu->save();
        $this->gmaas->save();
        $this->madenci->save();
                    }elseif($this->seviye->get($ad) == 2){
                        
        $this->okkkk($player);
        $this->oduncu->save();
        $this->gmaas->save();
        $this->madenci->save();
                    }elseif($this->seviye->get($ad) == 3){
                        
        $this->okkk($player);
        $this->oduncu->save();
        $this->gmaas->save();
        $this->madenci->save();
	}
}
}
	public function oduncuk(BlockBreakEvent $e){
		$ad = $e->getPlayer()->getName();
		$player = $e->getPlayer();	
	$block = $e->getBlock();
	
	if($e->getBlock()->getId() == 17){
	    
               $this->oduncu->set($ad,$this->oduncu->get($ad) +1);
        $this->oduncu->save();
        $this->gmaas->save();
        $this->madenci->save();
		if($this->seviye->get($ad) == 0){
        $this->okkkk($player);
        $this->oduncu->save();
        $this->gmaas->save();
        $this->madenci->save();
                    }elseif($this->seviye->get($ad) == 1){
                        
        $this->okk($player);
        $this->oduncu->save();
        $this->gmaas->save();
        $this->madenci->save();
                    }elseif($this->seviye->get($ad) == 2){
                        
        $this->okkkk($player);
        $this->oduncu->save();
        $this->gmaas->save();
        $this->madenci->save();
                    }elseif($this->seviye->get($ad) == 3){
                        
        $this->okkk($player);
        $this->oduncu->save();
        $this->gmaas->save();
        $this->madenci->save();
	}
}
}
  public function mesleksec($player){
 	$api = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
 	$form = $api->createSimpleForm(function (Player $player, array $data){
      	$ad = $player->getPlayer()->getName();
 		$re = $data[0];
 		if($re === null){
 			return false;
 			}
 			switch($re){
 				case 0:
 				    
        $this->oduncu->set($ad, 0);
        $this->mtp->set($ad, 0);
        $this->madenci->set($ad, 0);
        $this->mseviye->set($ad, 0);
        $this->oseviye->set($ad, 0);
        $this->gmaas->set($ad, 250);
        $meslekc = new Config($this->getDataFolder()."meslekler.yml", Config::YAML);
        $meslekc->set($player->getName(), "madenci");
        
        $player->sendMessage("§8[§fMeslek X§8]§7 Mesleğin başarıyla seçildi.");
        
        $meslekc->save();
        $this->mtp->save();
        $this->gmaas->save();
        $this->oduncu->save();
        $this->oseviye->save();
        $this->mseviye->save();
        $this->madenci->save();
        break;
        case 1:
        $this->oduncu->set($ad, 0);
        $this->mtp->set($ad, 0);
        $this->madenci->set($ad, 0);
        $this->mseviye->set($ad, 0);
        $this->oseviye->set($ad, 0);
        $this->gmaas->set($ad, 250);
        $meslekc = new Config($this->getDataFolder()."meslekler.yml", Config::YAML);
        $meslekc->set($player->getName(), "oduncu");
        $player->sendMessage("§8[§fMeslek X§8]§7 Mesleğin başarıyla seçildi.");
        
        $meslekc->save();
        $this->mtp->save();
        $this->oduncu->save();
        $this->oseviye->save();
        $this->gmaas->save();
        $this->mseviye->save();
        $this->madenci->save();
        break;
      }
    });
    $form->setTitle("Meslek Seç");
	$form->addButton("Madenci", 0, "textures/items/stone_pickaxe");
	$form->addButton("Oduncu", 0, "textures/items/stone_axe");
    $form->sendToPlayer($player);
  }
  public function oduncuxs($player){
 	$api = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
 	$form = $api->createSimpleForm(function (Player $player, array $data){
 		$re = $data[0];
 		if($re === null){
 			return false;
 			}
 			switch($re){
 				case 0:
 				    $this->gkazanc($player);
        break;
        case 1:
            break;
      }
    });
    $form->setTitle("Meslek Bilgilerin");
		$form->setContent("\n\n\n\n§eMesleğin§7:§f Oduncu\n\n\n\n§eMeslek Seviyen§7:§f ".$this->mseviye->get($player->getName())."\n\n\n\n§aKırılan Odunlar§7:§f ".$this->oduncu->get($player->getName()));
		$form->addButton("Meslek işlemleri");
		$form->addButton("Menüyü Kapat");
    $form->sendToPlayer($player);
  }
  public function madencis($player){
 	$api = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
 	$form = $api->createSimpleForm(function (Player $player, array $data){
 		$re = $data[0];
 		if($re === null){
 			return false;
 			}
 			switch($re){
 				case 0:
 				    $this->gkazanc($player);
        break;
        case 1:
            break;
      }
    });
    $form->setTitle("Meslek Bilgilerin");
		$form->setContent("\n\n\n\n§eMesleğin§7:§f Madenci\n\n\n\n§eMeslek Seviyen§7:§f ".$this->mseviye->get($player->getName())."\n\n\n\n§aKırılan Taşlar§7:§f ".$this->madenci->get($player->getName()));
		$form->addButton("Meslek işlemleri");
		$form->addButton("Menüyü Kapat");
    $form->sendToPlayer($player);
  }
  
	public function mbirak($player){

        $o = $player->getPlayer();
        
        $meslekc = new Config($this->getDataFolder()."meslekler.yml", Config::YAML);
        $meslekc->set($o->getName(), "bos");
        
        $meslekc->save();
        $o->sendMessage("§8[§fMeslek X§8]§7 Mesleğini başarıyla bıraktın");
        $o->sendMessage("§8[§fMeslek X§8]§7 Artık işsizsin!");
	}
  public function gkazanc($player){
 	$api = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
 	$form = $api->createSimpleForm(function (Player $player, array $data){
 		$re = $data[0];
 		if($re === null){
 			return false;
 			}
 			switch($re){
 				case 0:
 				    $this->maas($player);
        break;
        case 1:
 				    $this->mbirak($player);
            break;
      }
    });
    $form->setTitle("Meslek işlemleri");
		$form->setContent("\n\n\n\n§aGünlük Maaşın§7:§f ".$this->gmaas->get($player->getName())."\n\n\n\n§aMeslekten aldığın toplam para§7:§f ".$this->mtp->get($player->getName())."\n\n\n");
		$form->addButton("Maaşını Al");
		$form->addButton("Mesleğini Bırak");
    $form->sendToPlayer($player);
  }
  public function oduncus($player){
 	$api = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
 	$form = $api->createCustomForm(function (Player $player, array $data){
 		$re = $data[0];
 		if($re === null){
 			return false;
 			}
 			switch($re){
 				case 0:
        break;
      }
    });
    $ooseviye = $this->oseviye();
    $kodunlar = $this->oduncu();
    $form->setTitle("Meslek Bilgilerin");
	$form->addLabel("§eMesleğin§f: Oduncu");
	$form->addLabel("\n\n§eMeslek Seviyen§f: $ooseviye");
	$form->addLabel("\n§eMeslekten kazandığın para§f: $oduncutoplampara");
	$form->addLabel("\n§aKırılan Odunlar§f: $kodunlar");
	$form->addLabel("\n§aGünlük maaşın : §f$gmaaso §aTL");
    $form->sendToPlayer($player);
  }
  public function maas($g){
  	$o = $g->getPlayer();
      	$ad = $g->getPlayer()->getName();
  	 $cfg = $this->cfg->get($g->getName());
  
  	 if($cfg["Unix-2"] <= time()-$cfg["Unix-1"]){
  	//Maas
         $md = $this->gmaas->get($g->getName());
               $this->mtp->set($ad,$this->mtp->get($ad) +$md);
        $this->mtp->save();
			EconomyAPI::getInstance()->addMoney($g, $md);
  	  $g->sendMessage("§8[§fMeslek X§8]§7 $md §aTL§7 hesabınıza eklendi!");
      $this->gmaas->set($ad, 250);
  	  $bugun = date("d.m.Y");
  	  $bitis = strtotime("1 days", strtotime($bugun));
      $bitis = date("d.m.Y", $bitis);
      $gelecek = strtotime('+1 days');
      $unix = $gelecek-time();
  	  $this->cfg->set($g->getName(), [
            "Alınan-Zaman" => $bugun,
            "Birdaha-Alıcagı-Zaman" => $bitis,
            "Unix-1" => time(),
            "Unix-2" => $unix
  	                                 ]);
  	  $this->cfg->save();
        $this->mtp->save();
        $this->gmaas->save();
        $this->oduncu->save();
        $this->oseviye->save();
        $this->mseviye->save();
        $this->madenci->save();
  	   }else{
      $g->sendMessage("§8[§cX§8]§7 Maaşını günde 1 defa alabilirsin.");
      
      
  	  }
  
  	}
}